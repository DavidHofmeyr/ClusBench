backdownload <- function (url, destfile, retries = 3){
  attempt <- 1
  while (attempt <= retries) {
    tryCatch({
      utils::download.file(url, destfile, mode = "wb",
                           method = "libcurl",
                           quiet = FALSE)
      message("Download successful.")
      return(TRUE)
    }, error = function(e) {
      message(paste("Attempt", attempt, "failed:", e$message))
      attempt <<- attempt + 1
    })
  }
  warning("Download failed after ", retries, " attempts.")
  return(FALSE)
}



sampleXy <- function(X, y, n, k = NULL, vthresh = .9, prob = "raw", PCmax = 50, PCmin = 2){
  y <- as.numeric(as.factor(y))
  if(prob=="raw") pis <- table(y)/length(y)
  else pis <- rep(1/max(y), max(y))
  comps <- sample(1:max(y), n, prob = pis, replace = TRUE)
  counts <- sapply(1:max(y), function(j) sum(comps==j))
  x <- matrix(0, n, ncol(X))
  yy <- numeric(n)
  for(j in 1:max(y)){
    if(counts[j] > 0){
      x[comps==j,] <- sampleX(matrix(X[y==j,], nrow = sum(y==j)), counts[j], k, vthresh, PCmax, PCmin)
      yy[comps==j] <- j
    }
  }
  list(X = x, y = yy)
}

sampleX <- function(X, n, k = NULL, vthresh = 0.9, PCmax = 50, PCmin = 2, return_ids = FALSE){
  n0 <- nrow(X)
  d <- ncol(X)
  if(is.null(k)) k <- max(2, 2*floor(log(n0)))
  if(n0==1) return(matrix(X, n, d, byrow = TRUE) + rnorm(n*d))
  else if(n0 <= k & n0 > 1) return(mvtnorm::rmvnorm(n, sigma = cov(X)+diag(d)*1e-7))
  scl <- apply(X, 2, sd)
  scl[scl==0] <- 1
  X <- X/matrix(scl, n0, d, byrow = T)
  C <- cov(X)
  E <- eigen(C)
  g <- max(PCmin, min(PCmax, which(cumsum(E$values)/sum(E$values) >= vthresh)))
  mu0 <- colMeans(X)
  Z <- t(t(X)-mu0)%*%E$vectors[,1:g]
  ns <- FNN::get.knn(Z, k)$nn.index
  L <- Matrix::sparseMatrix(i=rep(1:n0, k), j = ns, dims = c(n0, n0))
  mu <- as.matrix(L%*%Z)/k
  muu <- as.matrix(L%*%Z^2)/k
  S <- sqrt(muu - mu^2)
  S[is.na(S)] <- 0
  ids <- sample(1:n0, n, replace = TRUE)
  x <- mu[ids,] + matrix(rnorm(n*g), n, g)*S[ids,] + mvtnorm::rmvnorm(n, sigma = cov(Z-mu) + diag(g)*1e-10)/2
  if(g==d-1){
    x <- cbind(x, rnorm(n)*sqrt(abs(E$values[d])))
  }
  else if(g < d){
    x <- cbind(x, matrix(rnorm(n*(d-g)), n, d-g)%*%diag(sqrt(abs(E$values[(g+1):d]))))
  }
  if(return_ids) list(X = (x%*%t(E$vectors) + matrix(mu0, n, d, byrow = TRUE))%*%diag(scl), ids = ids)
  else (x%*%t(E$vectors) + matrix(mu0, n, d, byrow = TRUE))%*%diag(scl)
}


get_data <- function (dataset_name, version = 1, local_cache_dir = NA){
  github <- "https://github.com/DavidHofmeyr/ClusBench/raw/refs/heads/master/data/"
  use_url <- paste0(github, "data", URLencode(dataset_name),
                    "/", URLencode(dataset_name),
                    "_", version, ".parquet")


  if (is.na(local_cache_dir)){
    tmp <- tempfile()
    if (backdownload(use_url, tmp)) dataset <- as.data.frame(arrow::read_parquet(tmp))
    else dataset <- NULL
  }
  else {
    if (!file.exists(local_cache_dir)) dir.create(file.path(local_cache_dir))

    dataset_path <- file.path(local_cache_dir, paste0(dataset_name, "_", version, ".parquet"))
    if (file.exists(dataset_path)) dataset <- as.data.frame(arrow::read_parquet(dataset_path))
    else {
      if(backdownload(use_url, dataset_path)) dataset <- as.data.frame(arrow::read_parquet(dataset_path))
      else dataset <- NULL
    }
  }
  dataset
}
